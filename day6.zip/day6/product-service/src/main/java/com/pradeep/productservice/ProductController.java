package com.pradeep.productservice;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	
	@Value("${server.port}")
	private String port;
	
	
	Logger logger=Logger.getLogger("com.pradeep.productservice.ProductController");

	public ProductController() {
		logger.info("=====ProductController Created====");
}
	
	@GetMapping("/names")
	public List<String> getAllProducts(){
		logger.info("=====ProductController calling getAllProducts====");
		return Arrays.asList("Mobile","Router","Camera",port);
	}
		
}
